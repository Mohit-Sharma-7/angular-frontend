package com.cognizant.agriserve.trainingservice.client;

import com.cognizant.agriserve.trainingservice.dto.response.FarmerResponseDTO;
import org.springframework.stereotype.Component;

@Component
public class FarmerClientFallback implements FarmerClient {

//    @Override
//    public FarmerResponseDTO getFarmerByUserId(Long userId) {
//        // Throw a custom exception that your GlobalExceptionHandler can catch
//        throw new RuntimeException("Farmer Service is currently unreachable. Workshop registration paused.");
//
//    }
@Override
public FarmerResponseDTO getFarmerByUserId(Long userId) {
    // We stopped throwing the exception!
    // Now we just print a warning and return a mock farmer to keep the app alive.
    System.out.println("⚠️ Farmer Service unreachable. Bypassing check for Farmer ID: " + userId);

    FarmerResponseDTO mockFarmer = new FarmerResponseDTO();

    // Assuming your DTO has a setFarmerId method (from Lombok @Data).
    // If it's named setId(), just change this line!
    mockFarmer.setFarmerId(userId);

    return mockFarmer;
}
}