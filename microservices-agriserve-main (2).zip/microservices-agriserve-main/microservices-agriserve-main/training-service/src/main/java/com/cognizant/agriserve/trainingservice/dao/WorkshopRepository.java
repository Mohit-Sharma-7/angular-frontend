package com.cognizant.agriserve.trainingservice.dao;

import com.cognizant.agriserve.trainingservice.entity.Workshop;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface WorkshopRepository extends JpaRepository<Workshop, Long> {


    List<Workshop> findByOfficerId(Long officerId);

    List<Workshop> findByTrainingProgram_ProgramIdAndDateAfter(Long programId, LocalDateTime date);
    List<Workshop> findByTrainingProgram_ProgramId(Long programId);
}

