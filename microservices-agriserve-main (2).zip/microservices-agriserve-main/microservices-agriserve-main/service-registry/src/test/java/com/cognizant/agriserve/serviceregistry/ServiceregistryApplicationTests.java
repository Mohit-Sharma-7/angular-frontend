package com.cognizant.agriserve.serviceregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceregistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
